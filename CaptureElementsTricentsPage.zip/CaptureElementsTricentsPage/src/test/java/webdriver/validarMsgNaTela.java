package webdriver;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import pages.enterVehicleData;

//classe que efetua a chamadas dos metodos
public class validarMsgNaTela {


private WebDriver navegador;


@Rule
public TestName test = new TestName();

@Before
public void setup (){
    setNavegador(suporte.web.createChrome());
}

@Test
public void enterVehicleData () {
	new enterVehicleData(getNavegador())
	.abaEnterVehicleData()
	.abaEnterInsuranceData()
	.abaEnterProductData()
	.abaSelectPriceOption()
	.abaSendQuote()
	;}

@After
public void tearDown () {
	//Valida��o objetivo do teste 
    String mensagemObtida = navegador.findElement(By.cssSelector("body > div.sweet-alert.showSweetAlert.visible > h2")).getText();
    String mensagemResultEsperado = "Sending e-mail failed!";//todos emails falharam
    Assert.assertEquals(mensagemObtida,mensagemResultEsperado);
	getNavegador().quit();
}

public WebDriver getNavegador() {
	return navegador;
}

public void setNavegador(WebDriver navegador) {
	this.navegador = navegador;
}

}