package webdriver;


public class chamarScript extends validarMsgNaTela {
	
	//Classe Metodo principal
	public static void main(String[] args) {
		
	}
}


