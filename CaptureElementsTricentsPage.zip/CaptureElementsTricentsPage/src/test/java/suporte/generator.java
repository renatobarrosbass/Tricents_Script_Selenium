package suporte;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;

public class generator {

	// gerando o nome do arquivo de printscreen
	public static String dataHoraParaArquivo (){

        Timestamp ts = new Timestamp(System.currentTimeMillis());
        return new SimpleDateFormat("yyyyMMddhhmmss").format(ts);
    }

}