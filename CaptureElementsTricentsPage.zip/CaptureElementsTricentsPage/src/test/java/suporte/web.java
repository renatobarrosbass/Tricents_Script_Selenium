package suporte;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class web {

	
	//Buscar o drive do ChromeCast
    public static WebDriver createChrome (){

        System.setProperty("webdriver.chrome.driver", "C:/Tools/selenium/chromedriver.exe");

        //instanciar pagina Tricents
        WebDriver navegador;
        navegador = new ChromeDriver();
        navegador.get("http://sampleapp.tricentis.com/101/app.php");
        
        return navegador;
    }


}
