package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import suporte.generator;
import suporte.screenshot;



public class enterInsuranceData {
	
	private WebDriver navegador;
	
	public enterInsuranceData(WebDriver navegador) {this.navegador = navegador;}
	
	public  enterProductData abaEnterInsuranceData () {
		
		//Setar nome Usuario apolice
		navegador.findElement(By.id("firstname")).sendKeys("Renato");
		 
		//Setar Sobrenome Segurado
		navegador.findElement(By.id("lastname")).sendKeys("Barros");
		 
		//Setar ano nascimento
		navegador.findElement(By.id("birthdate")).sendKeys("11/05/1978");
		 
		//Setar G�nero Segurado
		navegador.findElement(By.xpath("//*[@id=\"insurance-form\"]/div/section[2]/div[4]/p/label[1]/span")).click();
		 
		//setar Pa�s Origem Segurado
		navegador.findElement(By.xpath("//*[@id=\"country\"]/option[32]")).click();
		 
		//selecionar "CEP" do segurado
		navegador.findElement(By.id("zipcode")).sendKeys("53130000");
		 
		//situacao: qual a ocupacao do Segurado
		navegador.findElement(By.xpath("//*[@id=\"occupation\"]/option[5]")).click();
		 
		//hobbies segurado
		boolean hobbiesInformados;
	    if (navegador.findElement(By.xpath("//*[@id=\"insurance-form\"]/div/section[2]/div[10]/p/label[2]/span")).
	        		isSelected())hobbiesInformados = true;
	    else hobbiesInformados = false;
	        if (!hobbiesInformados){
	            navegador.findElement(By.xpath("//*[@id=\"insurance-form\"]/div/section[2]/div[10]/p/label[2]/span")).click();
	        }
	        
	    //Tirando um printscreen da mensagem obtida
	    screenshot.tirar(navegador, "C:/Tools/selenium/PrintScreen_Tricents/" + generator.dataHoraParaArquivo() + "validarMensagemNaTela.png");
	        
	    //setar Next 2
	    navegador.findElement(By.id("nextenterproductdata")).click();
	     
	    return new enterProductData (navegador);
	    
		
	}
}
