package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import suporte.generator;
import suporte.screenshot;

public class selectPriceOption {
	
	private WebDriver navegador;

	public selectPriceOption(WebDriver navegador) {
		this.navegador = navegador;
	}
	
	public sendQuote abaSelectPriceOption () {
		//Selecionar Ultimate no checkbox
        boolean opcaoSetada;
        if (navegador.findElement(By.xpath("//*[@id=\"priceTable\"]/tfoot/tr/th[2]/label[4]/span")).isSelected())
            opcaoSetada = true;
        else opcaoSetada = false;
        if (!opcaoSetada) {
            navegador.findElement(By.xpath("//*[@id=\"priceTable\"]/tfoot/tr/th[2]/label[4]/span")).click();
        }
        
        //Aguarda exibir bt Next
        WebDriver driver = navegador;
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("nextsendquote")));
        
        //Tirando um printscreen da mensagem obtida
        screenshot.tirar(navegador, "C:/Tools/selenium/PrintScreen_Tricents/" + generator.dataHoraParaArquivo() + "validarMensagemNaTela.png");
        
        //clicar bt Next
		navegador.findElement(By.xpath("//*[@id=\"nextsendquote\"]")).click();
		
		return new sendQuote (navegador);
	}
		
}
