package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import suporte.generator;
import suporte.screenshot;

public class enterVehicleData {

	private WebDriver navegador;

	public enterVehicleData(WebDriver navegador) { this.navegador = navegador;}
	
	public enterInsuranceData abaEnterVehicleData () {
	  //enterVehicleDataFillOut
	  // Setar marca veiculo 
	  WebElement setarMakeType = navegador.findElement(By.cssSelector("#make > option:nth-child(5)"));
	  setarMakeType.click();
	        
	  //Setar Modelo do Veiculo
	  navegador.findElement(By.xpath("//*[@id=\"model\"]/option[3]")).click();
	    
	  //Setar Qtde Cilindros do Veiculo
	    
	  navegador.findElement(By.id("cylindercapacity")).sendKeys("2000");
	    
	  //Setar Pot�ncia do Motor
	  navegador.findElement(By.id("engineperformance")).sendKeys("2000");
	    
      // Setar data/ ano modelo fabrica��o
	  navegador.findElement(By.id("dateofmanufacture")).sendKeys("10/01/2018");
	    
	  //Setar Numero de Lugares do Veiculo
	  navegador.findElement(By.xpath("//*[@id=\"numberofseats\"]/option[6]")).click();
	    
	  //Metodo para indicar se deseja Ajuste de Altura de Direcao
      navegador.findElement(By.xpath("//*[@id=\"insurance-form\"]/div/section[1]/div[7]/p/label[1]/span")).click();
       
      //Metodo para indicar numero de Lugares Secundarios (reclinavel, algo desse tipo);
      navegador.findElement(By.xpath("//*[@id=\"numberofseatsmotorcycle\"]/option[4]")).click();
      
      //Setar tipo de Combustivel do veiculo
      navegador.findElement(By.xpath("//*[@id=\"fuel\"]/option[4]")).click();
	        
      //Setar carga maxima
      navegador.findElement(By.id("payload")).sendKeys("1000");
      
      //Metodo para setar o Peso total do Veiculo carregado
      navegador.findElement(By.id("totalweight")).sendKeys("1000");
      
      //Setar preco do Veiculo
      navegador.findElement(By.id("listprice")).sendKeys("1000");
      
      //Setar Kilometragem Anual
      navegador.findElement(By.id("annualmileage")).sendKeys("1000");
      
      //Tirando um printscreen da mensagem obtida
      screenshot.tirar(navegador, "C:/Tools/selenium/PrintScreen_Tricents/" + generator.dataHoraParaArquivo() + "validarMensagemNaTela.png");
      
      //Clicar no Botao NEXT para Aba "Enter Insurant Data"
      navegador.findElement(By.xpath("//*[@id=\"nextenterinsurantdata\"]")).click();
      
      // Espera explicita possibilitando verificar elemento qdo estiver vis�vel
      WebDriver driver = navegador;
      WebDriverWait wait = new WebDriverWait(driver, 10);
      wait.until(ExpectedConditions.presenceOfElementLocated(By.id("enterinsurantdata")));
      
      return new enterInsuranceData (navegador);
      
	}

}
