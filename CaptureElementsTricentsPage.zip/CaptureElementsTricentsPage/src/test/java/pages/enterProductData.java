package pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
//import org.openqa.selenium.support.ui.*;
//import org.openqa.

import suporte.generator;
import suporte.screenshot;

public class enterProductData {

	private WebDriver navegador;

	public enterProductData(WebDriver navegador) {this.navegador = navegador;}

	public selectPriceOption abaEnterProductData() {

		//aguardar calend�rio carregar
				
		/*boolean dataInicio;
	    if (navegador.findElement(By.id("startdate")).isDisplayed())dataInicio = true;
	       else dataInicio = false;
	        	if (!dataInicio){
	        	navegador.findElement(By.id("startdate")).sendKeys("07/18/2020");
	        }*/
		
		
		// setar Data garantia;
		navegador.findElement(By.id("startdate")).sendKeys("07/18/2020");
				
	      
		// setar valor da apolice
		navegador.findElement(By.xpath("//*[@id=\"insurancesum\"]/option[6]")).click();

		// setar valor da Cobertura
		navegador.findElement(By.xpath("//*[@id=\"meritrating\"]/option[7]")).click();

		// setar tipo de Cobertura
		navegador.findElement(By.xpath("//*[@id=\"damageinsurance\"]/option[4]")).click();
		navegador.manage().timeouts().implicitlyWait(03, TimeUnit.SECONDS);

		// setar produto opcional
		boolean setarProdOpc;
		if (navegador.findElement(By.xpath("//*[@id=\"insurance-form\"]/div/section[3]/div[5]/p/label[1]/span"))
				.isSelected())
			setarProdOpc = true;
		else
			setarProdOpc = false;
		if (!setarProdOpc) {navegador.findElement(By.xpath("//*[@id=\"insurance-form\"]/div/section[3]/div[5]/p/label[1]/span")).click();}

		// setar carro opcional
		WebElement cortesia = navegador.findElement(By.xpath("//*[@id=\"courtesycar\"]/option[3]"));
		cortesia.click();
		//navegador.findElement(By.xpath("//*[@id=\"courtesycar\"]/option[3]")).click();
		
		 //Tirando um printscreen da mensagem obtida
        screenshot.tirar(navegador, "C:/Tools/selenium/PrintScreen_Tricents/" + generator.dataHoraParaArquivo() + "validarMensagemNaTela.png");

		//clicar bt next aba 'Select Price Option'
		navegador.findElement(By.id("nextselectpriceoption")).click();
		
		return new selectPriceOption (navegador);
		}
	    
	}