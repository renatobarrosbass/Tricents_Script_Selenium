package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import suporte.generator;
import suporte.screenshot;

public class sendQuote {
	
	private WebDriver navegador;

	public sendQuote(WebDriver navegador) {this.navegador = navegador;}

	public sendQuote abaSendQuote () {
		
		//Informar email do Segurado
        navegador.findElement(By.id("email")).sendKeys("qqemail@provedor.com");
        
        //setar nome do segurado
        navegador.findElement(By.id("username")).sendKeys("nomeDoUsuario");
        
        //setar senha segurado
        navegador.findElement(By.id("password")).sendKeys("suaSenha@123");

        //setar confirma��o senha
        navegador.findElement(By.id("confirmpassword")).sendKeys("suaSenha@123");
        
        //clicar enviar proposta
        navegador.findElement(By.id("sendemail")).click();
        
     // Espera explicita possibilitando verificar elemento qdo estiver vis�vel
        WebDriver driver = navegador;
        WebDriverWait wait = new WebDriverWait(driver, 20);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("body > div.sweet-alert.showSweetAlert.visible > div.sa-button-container > button")));

        //Tirando um printscreen da mensagem obtida
        screenshot.tirar(navegador, "C:/Tools/selenium/PrintScreen_Tricents/" + generator.dataHoraParaArquivo() + "validarMensagemNaTela.png");

    return this;
	}
	
}
